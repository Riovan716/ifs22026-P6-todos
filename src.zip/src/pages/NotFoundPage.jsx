function NotFoundPage() {
  return (
    <div className="container pt-2">
      {" "}
      <div className="text-center text-danger">
        {" "}
        <h1>404</h1> <h3>Halaman Tidak Ditemukan</h3>{" "}
      </div>{" "}
    </div>
  );
}
export default NotFoundPage;
